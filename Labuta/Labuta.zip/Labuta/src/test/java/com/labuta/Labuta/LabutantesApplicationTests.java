package com.labuta.Labuta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabutantesApplicationTests {

	@Test
	void contextLoads() {
	}

}
